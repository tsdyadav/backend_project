import logging
import time
import json
import uuid
from typing import Optional

from fastapi import Request


class JSONFormatter(logging.Formatter):
    def format(self, record):
        data = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "message": record.getMessage(),
        }
        if hasattr(record, "extra") and isinstance(record.extra, dict):
            data.update(record.extra)
        return json.dumps(data)


def setup_logging(level: str = "INFO"):
    root = logging.getLogger()
    handler = logging.StreamHandler()
    handler.setFormatter(JSONFormatter())
    root.handlers = [handler]
    root.setLevel(level)


def request_extra(
    request_id: str,
    request: Request,
    status: int,
    latency_ms: float,
    message_id: Optional[str] = None,
    dup: Optional[bool] = None,
    result: Optional[str] = None,
):
    extra = {
        "request_id": request_id,
        "method": request.method,
        "path": request.url.path,
        "status": status,
        "latency_ms": round(latency_ms, 2),
    }
    if message_id is not None:
        extra["message_id"] = message_id
    if dup is not None:
        extra["dup"] = dup
    if result is not None:
        extra["result"] = result
    return extra
