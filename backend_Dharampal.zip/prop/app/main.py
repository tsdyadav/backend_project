import hmac
import hashlib
import uuid
import time
from typing import Optional

from fastapi import FastAPI, Request, Header, HTTPException, Depends, Query
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field, constr, validator

from .config import settings
from .storage import init_db, insert_message, list_messages, get_stats
from .logging_utils import setup_logging, request_extra
from .metrics import http_requests_total, webhook_requests_total, request_latency_seconds, metrics_response

import logging

app = FastAPI()
logger = logging.getLogger("api")


class WebhookIn(BaseModel):
    message_id: constr(min_length=1)
    from_: constr(min_length=2) = Field(..., alias="from")
    to: constr(min_length=2)
    ts: constr(min_length=1)
    text: Optional[constr(max_length=4096)] = None

    @validator("from_", "to")
    def e164_like(cls, v):
        if not v.startswith("+") or not v[1:].isdigit():
            raise ValueError("must be E.164-like")
        return v

    @validator("ts")
    def ts_must_end_with_z(cls, v):
        if not v.endswith("Z"):
            raise ValueError("ts must be UTC with Z suffix")
        return v


class MessagesOut(BaseModel):
    data: list
    total: int
    limit: int
    offset: int


@app.on_event("startup")
async def startup_event():
    # Setup logging
    setup_logging(settings.LOG_LEVEL)
    logger.info("app.startup")

    # Initialize DB
    try:
        init_db()
        logger.info("db.initialized")
    except Exception as e:
        logger.exception("db.init_failed")


@app.middleware("http")
async def add_logging_and_metrics(request: Request, call_next):
    request_id = str(uuid.uuid4())
    start = time.time()
    try:
        response = await call_next(request)
        status = response.status_code
    except Exception as exc:
        status = 500
        raise
    finally:
        latency = (time.time() - start)
        request_latency_seconds.observe(latency)
        path = request.url.path
        http_requests_total.labels(path=path, status=str(status)).inc()
        # log
        extra = request_extra(request_id, request, status, latency * 1000)
        logger.info("request.complete", extra=extra)
    return response


@app.post("/webhook")
async def webhook(request: Request, x_signature: Optional[str] = Header(None)):
    raw = await request.body()

    if not settings.WEBHOOK_SECRET:
        # invalid ready state; treat as server error
        raise HTTPException(status_code=503, detail="server not ready")

    if not x_signature:
        webhook_requests_total.labels(result="invalid_signature").inc()
        extra = request_extra(str(uuid.uuid4()), request, 401, 0)
        logger.error("invalid signature: missing", extra=extra)
        raise HTTPException(status_code=401, detail="invalid signature")

    computed = hmac.new(settings.WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(computed, x_signature):
        webhook_requests_total.labels(result="invalid_signature").inc()
        extra = request_extra(str(uuid.uuid4()), request, 401, 0)
        logger.error("invalid signature: mismatch", extra=extra)
        raise HTTPException(status_code=401, detail="invalid signature")

    # parse JSON and validate
    try:
        payload = WebhookIn.parse_raw(raw)
    except Exception as e:
        webhook_requests_total.labels(result="validation_error").inc()
        extra = request_extra(str(uuid.uuid4()), request, 422, 0)
        logger.error("validation_error", extra=extra)
        raise

    pdata = payload.dict(by_alias=True)
    # Insert, idempotent
    created, err = insert_message(pdata)
    if err:
        webhook_requests_total.labels(result="error").inc()
        extra = request_extra(str(uuid.uuid4()), request, 500, 0, message_id=pdata.get("message_id"), dup=False, result="error")
        logger.error("insert_error", extra=extra)
        raise HTTPException(status_code=500, detail="insert failed")

    if created:
        webhook_requests_total.labels(result="created").inc()
        extra = request_extra(str(uuid.uuid4()), request, 200, 0, message_id=pdata.get("message_id"), dup=False, result="created")
        logger.info("webhook.created", extra=extra)
    else:
        webhook_requests_total.labels(result="duplicate").inc()
        extra = request_extra(str(uuid.uuid4()), request, 200, 0, message_id=pdata.get("message_id"), dup=True, result="duplicate")
        logger.info("webhook.duplicate", extra=extra)

    return JSONResponse({"status": "ok"})


@app.get("/messages")
async def get_messages(
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    from_: Optional[str] = Query(None, alias="from"),
    since: Optional[str] = None,
    q: Optional[str] = None,
):
    data, total = list_messages(limit=limit, offset=offset, from_msisdn=from_, since=since, q=q)
    resp = {"data": data, "total": total, "limit": limit, "offset": offset}
    return resp


@app.get("/stats")
async def stats():
    return get_stats()


@app.get("/health/live")
async def health_live():
    return JSONResponse({"status": "ok"})


@app.get("/health/ready")
async def health_ready():
    # DB reachable and WEBHOOK_SECRET set
    import sqlite3
    try:
        if not settings.WEBHOOK_SECRET:
            raise HTTPException(status_code=503, detail="no webhook secret configured")
        # simple query
        from .storage import engine

        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return JSONResponse({"status": "ok"})
    except Exception:
        raise HTTPException(status_code=503, detail="not ready")


@app.get("/metrics")
async def metrics():
    data, content_type = metrics_response()
    return PlainTextResponse(content=data.decode(), media_type=content_type)
