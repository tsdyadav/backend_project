import datetime
import sqlite3
from contextlib import contextmanager
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from .models import Base, Message
from .config import settings


engine = create_engine(settings.DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


@contextmanager
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def insert_message(payload: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    """Insert message. Returns (created, error_message). created False means duplicate.
    """
    from sqlalchemy.orm import Session

    with get_db() as db:  # type: Session
        msg = Message(
            message_id=payload["message_id"],
            from_msisdn=payload["from"],
            to_msisdn=payload["to"],
            ts=payload["ts"],
            text=payload.get("text"),
            created_at=datetime.datetime.utcnow().isoformat() + "Z",
        )
        db.add(msg)
        try:
            db.commit()
            return True, None
        except IntegrityError as e:
            db.rollback()
            # Assume duplicate
            return False, None
        except Exception as e:
            db.rollback()
            return False, str(e)


def list_messages(
    limit: int = 50,
    offset: int = 0,
    from_msisdn: Optional[str] = None,
    since: Optional[str] = None,
    q: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], int]:
    from sqlalchemy import select, func
    from sqlalchemy.orm import Session

    with get_db() as db:  # type: Session
        stmt = select(Message)
        count_stmt = select(func.count()).select_from(Message)

        if from_msisdn:
            stmt = stmt.where(Message.from_msisdn == from_msisdn)
            count_stmt = count_stmt.where(Message.from_msisdn == from_msisdn)
        if since:
            stmt = stmt.where(Message.ts >= since)
            count_stmt = count_stmt.where(Message.ts >= since)
        if q:
            stmt = stmt.where(Message.text.ilike(f"%{q}%"))
            count_stmt = count_stmt.where(Message.text.ilike(f"%{q}%"))

        stmt = stmt.order_by(Message.ts.asc(), Message.message_id.asc()).limit(limit).offset(offset)

        total = db.execute(count_stmt).scalar_one()
        rows = db.execute(stmt).scalars().all()

        data = [
            {
                "message_id": r.message_id,
                "from": r.from_msisdn,
                "to": r.to_msisdn,
                "ts": r.ts,
                "text": r.text,
            }
            for r in rows
        ]
        return data, int(total)


def get_stats() -> Dict[str, Any]:
    from sqlalchemy import select, func
    from sqlalchemy.orm import Session

    with get_db() as db:  # type: Session
        total = db.execute(select(func.count()).select_from(Message)).scalar_one()
        senders = db.execute(select(Message.from_msisdn, func.count().label("c")).group_by(Message.from_msisdn).order_by(func.count().desc()).limit(10)).all()
        messages_per_sender = [{"from": s[0], "count": int(s[1])} for s in senders]
        senders_count = db.execute(select(func.count(func.distinct(Message.from_msisdn)))).scalar_one()
        first_ts = db.execute(select(func.min(Message.ts))).scalar_one()
        last_ts = db.execute(select(func.max(Message.ts))).scalar_one()

        return {
            "total_messages": int(total),
            "senders_count": int(senders_count),
            "messages_per_sender": messages_per_sender,
            "first_message_ts": first_ts,
            "last_message_ts": last_ts,
        }
