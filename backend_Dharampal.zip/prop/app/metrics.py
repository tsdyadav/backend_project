from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from prometheus_client import CollectorRegistry

registry = CollectorRegistry()

http_requests_total = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["path", "status"],
    registry=registry,
)

webhook_requests_total = Counter(
    "webhook_requests_total",
    "Webhook processing outcomes",
    ["result"],
    registry=registry,
)

request_latency_seconds = Histogram(
    "request_latency_seconds",
    "Request latency in seconds",
    registry=registry,
)


def metrics_response():
    return generate_latest(registry), CONTENT_TYPE_LATEST
