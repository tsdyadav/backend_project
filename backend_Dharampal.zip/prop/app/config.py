import os
from pydantic import BaseSettings, AnyUrl, Field


class Settings(BaseSettings):
    DATABASE_URL: str = Field(..., env="DATABASE_URL")
    WEBHOOK_SECRET: str | None = Field(None, env="WEBHOOK_SECRET")
    LOG_LEVEL: str = Field("INFO", env="LOG_LEVEL")

    class Config:
        env_file = ".env"


settings = Settings()
