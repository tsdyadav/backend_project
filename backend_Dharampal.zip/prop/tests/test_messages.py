import os
os.environ["WEBHOOK_SECRET"] = "testsecret"
import hmac
import hashlib
from fastapi.testclient import TestClient
from app.main import app
from app.storage import init_db

client = TestClient(app)


def sign(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def setup_module(module):
    os.environ["WEBHOOK_SECRET"] = "testsecret"
    init_db()


def test_pagination_and_filters():
    # seed
    msgs = [
        ("m2", "+919876543211", "2025-01-15T09:00:00Z", "Earlier"),
        ("m3", "+911234567890", "2025-01-15T11:00:00Z", "Later"),
        ("m4", "+919876543211", "2025-01-15T12:00:00Z", "More"),
    ]
    for mid, fr, ts, text in msgs:
        body = ("{\"message_id\":\"%s\",\"from\":\"%s\",\"to\":\"+14155550100\",\"ts\":\"%s\",\"text\":\"%s\"}" % (mid, fr, ts, text)).encode()
        sig = sign(body, "testsecret")
        r = client.post("/webhook", data=body, headers={"X-Signature": sig})
        assert r.status_code == 200

    r = client.get("/messages?limit=2&offset=0")
    assert r.status_code == 200
    j = r.json()
    assert j["limit"] == 2
    assert len(j["data"]) <= 2

    # filter by from
    r = client.get("/messages?from=+919876543211")
    j = r.json()
    assert all(m["from"] == "+919876543211" for m in j["data"]) 

    # since filter
    r = client.get("/messages?since=2025-01-15T10:30:00Z")
    j = r.json()
    assert all(m["ts"] >= "2025-01-15T10:30:00Z" for m in j["data"]) 

    # q filter
    r = client.get("/messages?q=Earlier")
    j = r.json()
    assert any("Earlier" in (m.get("text") or "") for m in j["data"]) 
