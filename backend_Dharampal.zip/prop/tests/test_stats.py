import os
import hmac
import hashlib
from fastapi.testclient import TestClient
from app.main import app
from app.storage import init_db

client = TestClient(app)


def sign(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def setup_module(module):
    os.environ["WEBHOOK_SECRET"] = "testsecret"
    init_db()


def test_stats():
    # seed two messages from same sender
    body1 = b'{"message_id":"s1","from":"+911111111111","to":"+14155550100","ts":"2025-01-10T09:00:00Z","text":"A"}'
    body2 = b'{"message_id":"s2","from":"+912222222222","to":"+14155550100","ts":"2025-01-11T10:00:00Z","text":"B"}'
    sig1 = sign(body1, "testsecret")
    sig2 = sign(body2, "testsecret")
    client.post("/webhook", data=body1, headers={"X-Signature": sig1})
    client.post("/webhook", data=body2, headers={"X-Signature": sig2})

    r = client.get("/stats")
    assert r.status_code == 200
    j = r.json()
    assert j["total_messages"] >= 2
    assert j["senders_count"] >= 2
    assert isinstance(j["messages_per_sender"], list)
