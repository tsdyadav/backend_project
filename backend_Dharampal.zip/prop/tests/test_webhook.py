import os
import hmac
import hashlib
import json
from fastapi.testclient import TestClient

import os
os.environ["WEBHOOK_SECRET"] = "testsecret"

from app.main import app
from app.storage import init_db
from fastapi.testclient import TestClient

client = TestClient(app)


def sign(body: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def setup_module(module):
    init_db()


def test_invalid_signature():
    body = b'{"message_id":"m1","from":"+919876543210","to":"+14155550100","ts":"2025-01-15T10:00:00Z","text":"Hello"}'
    r = client.post("/webhook", data=body, headers={"X-Signature": "bad"})
    assert r.status_code == 401


def test_valid_insert_and_duplicate():
    body = b'{"message_id":"m1","from":"+919876543210","to":"+14155550100","ts":"2025-01-15T10:00:00Z","text":"Hello"}'
    sig = sign(body, "testsecret")
    r = client.post("/webhook", data=body, headers={"X-Signature": sig})
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}

    # duplicate
    r2 = client.post("/webhook", data=body, headers={"X-Signature": sig})
    assert r2.status_code == 200
    assert r2.json() == {"status": "ok"}
