# WhatsApp-like Webhook Service

A small FastAPI-based service to ingest WhatsApp-like messages via a signed webhook and provide listing, stats, metrics and health probes.

## Run

Set env vars and start the stack:

export WEBHOOK_SECRET="testsecret"
export DATABASE_URL="sqlite:////data/app.db"

make up

The API will be available at http://localhost:8000

Endpoints:
- POST /webhook
- GET /messages
- GET /stats
- GET /health/live
- GET /health/ready
- GET /metrics

## Tests

make test

## Design Decisions

- HMAC: signature computed as hex(HMAC_SHA256(secret=WEBHOOK_SECRET, message=<raw request body bytes>)). Verified with hmac.compare_digest.
- Pagination: `limit` (1-100, default 50), `offset` (>=0, default 0), filters: `from`, `since`, `q` (case-insensitive substring).
- Idempotency: enforced by SQLite PRIMARY KEY on `message_id`. Duplicate inserts are detected and treated as OK.
- Logs: structured JSON per-request. Required fields included: `ts`, `level`, `request_id`, `method`, `path`, `status`, `latency_ms`. Webhook logs include `message_id`, `dup`, and `result`.
- Metrics: Prometheus client with `http_requests_total` and `webhook_requests_total` and `request_latency_seconds`.

## Setup Used
VSCode + Copilot + occasional ChatGPT prompts
